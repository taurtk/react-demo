export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  SS: '/ss',
  FW: '/fw',
  PANTS: '/pants',
  T_SHIRT: '/t-shirt',
  SALE: '/sale',
  COLLECTION: '/collection',
  COMMUNITY: '/community',
  PRODUCTS: '/products',
} as const;