export const NAVIGATION_LINKS = [
  { name: 'SS', path: '/ss' },
  { name: 'FW', path: '/fw' },
  { name: 'PANTS', path: '/pants' },
  { name: 'T-SHIRT', path: '/t-shirt' },
  { name: 'SALE', path: '/sale' },
  { name: 'COLLECTION', path: '/collection' },
  { name: 'COMMUNITY', path: '/community' },
];